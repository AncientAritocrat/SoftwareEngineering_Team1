# vue2
> #### If you want to use this starter
> 
```
npm install
```

> #### If you want run this starter
```
npm run serve
```

> #### If you want build starter
```
npm run build:prod
```


