<template>
    <div class="listPanel">
        <div class="header">
             <div>全部图层</div>
            <el-switch
                v-model="allLayerOff"
                inline-prompt
                active-color="#777777"
                inactive-color="#13ce66"
                @change="doSwitchAllLayer"
            ></el-switch>
        </div>
        <el-scrollbar class="content">
                <div v-for="item in layers" :key="item.index" class="layeritem">
                    <div class="layer-colorBlock" :style="'background:' + item.color"></div>
                    <div class="layer-text" :title="item.name">{{ item.name }}</div>
                    <el-switch
                        v-model="item.isOff"
                        inline-prompt
                        active-color="#777777"
                        inactive-color="#13ce66"
                        @change="doSwitchLayer"
                    ></el-switch>
                </div>
        </el-scrollbar>
    </div>
</template>

<script >
export default {
  name: "LayerManage",
  components: {
  },
  props: ['layers'],
  data() {
    return {
        allLayerOff: true
    }
  },
  methods: {
    doSwitchAllLayer() {
        this.layers.forEach(e => e.isOff = this.allLayerOff);
        this.doSwitchLayer();
    },
    doSwitchLayer() {
        this.$emit("change", this.layers)
    }
  }
}
</script>

<style scoped lang="scss">
.listPanel {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;

    .header {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        border-bottom: 1px solid #989898;
        align-items: center;
    }

    .layeritem {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        margin: 5px;
        height: 40px;
        line-height: 40px;
        align-items: center;
        border-bottom: 1px solid #989898;
        position: relative;
        

        .layer-colorBlock {
            border: 1px solid #989898;
            display: inline-block;
            width: 16px;
            height: 100%;
        }
    }
    .content {
        height: 400px;
    }
  
    :deep .el-scrollbar__wrap {
        overflow-x: hidden !important;
    }
    .layer-text {
        flex: 1;
        text-align: left;
        margin-left: 5px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        word-break: break-all;
    }
}

::v-deep .el-scrollbar__wrap    {
    overflow-x: hidden;
}

</style>