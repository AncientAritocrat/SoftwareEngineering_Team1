<template>
  <div>
    <div id='map-container'/>
    <UILayer v-if="isLoaded"/>
  </div>
</template>

<script>
import { MapApp } from '@vjmap/common'
import vjmap from 'vjmap'
import 'vjmap/dist/vjmap.min.css'
import UILayer from '../components/UILayer.vue'
import config from '../data/config'
import { onMapLoaded } from '../lib/program'
export default {
  name: "Map",
  components: {
    UILayer
  },
  data() {
    return {
      mapApp: null,
      isLoaded: false
    }
  },
  mounted() {
    this.initMap();
  },
  provide() {
    return {
       getMap: ()=>this.mapApp.map,
       getMapApp: ()=>this.mapApp,
     };
  },
  methods: {
    async initMap() {
      this.mapApp =  new MapApp();
      const env = {
        serviceUrl: "https://vjmap.com/server/api/v1",
        accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6MSwiVXNlcm5hbWUiOiJyb290MSIsIk5pY2tOYW1lIjoicm9vdDEiLCJBdXRob3JpdHlJZCI6InJvb3QiLCJCdWZmZXJUaW1lIjo4NjQwMCwiZXhwIjoxOTQyMzA1MjQxLCJpc3MiOiJ2am1hcCIsIm5iZiI6MTYyNjk0NDI0MX0.29OAA4Cnjtw780VxIxWqduLtszp1EtpSNHAmWjiL_OM",
      };
      this.mapApp.mount("map-container");
      let cfg = config;
      let key = this.$route.query?.key;
      // 如果需要从服务器获取获取
      if (key) {
        let svc = new vjmap.Service(env.serviceUrl, env.accessToken);
        let keyInfo = "data_visual_" + key;
        let res = await svc.getCustomData(keyInfo, {retDataType: "value"});
        cfg = res.data;
        cfg.serviceUrl = cfg.serviceUrl ?? env.serviceUrl;
        cfg.serviceToken = cfg.serviceToken ?? env.accessToken;
      }
      cfg.serviceUrl = cfg.serviceUrl ?? env.serviceUrl;
      cfg.serviceToken = cfg.serviceToken ?? env.accessToken;
      // isDisableRunProgram设置为true，表示不执行配置中的逻辑代码，执行下面onMapLoaded函数中的代码，这样方便书写和调试
      this.mapApp.isDisableRunProgram = key ? false : true; // 如果通过url的key打开，则还是执行配置中的代码
      await this.mapApp.setConfig(cfg);
      if (this.mapApp.isDisableRunProgram) {
        // 方便在这里写逻辑代码调试，然后复制到配置中的逻辑代码中去
        await onMapLoaded(this.mapApp.map, this.mapApp);
      }
      this.isLoaded = true;
    }
  },
  destroyed() {
    if (this.mapApp) {
      this.mapApp.destory();
    }
  }
}
</script>

<style scoped>
  #map-container {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: #022B4F;
  }
</style>