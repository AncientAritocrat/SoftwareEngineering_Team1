<template>
  <div class="div-container">
    <ToolBar/>
  </div>
</template>

<script>
import ToolBar from "./ToolBar.vue";
export default {
name: "UILayer",
  components: {
    ToolBar
  },
}
</script>

<style scoped>
.div-container {
  z-index: 2
}
</style>