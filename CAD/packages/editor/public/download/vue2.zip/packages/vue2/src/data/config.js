export default {
  mapSources: [
  ],
  mapLayers: [
  ],
  mapOpenOptions: {
    mapid: "sys_zp",
    version: "v1",
    mapopenway: "GeomRender",
    isVectorStyle: false,
    style: {
      backcolor: 0,
    },
  },
  title: "project1",
};
