<template>
  <div>
    <div class="rt-card">
      <el-button-group v-if="!previewHideControl" class="toolbar">
        <el-popover placement="bottom" width="200" trigger="click">
          <LayerManage :layers="dataLayers" @change="changeDataLayer" />
          <el-button slot="reference" type="primary" size="mini">数据图层</el-button>
        </el-popover>
        <el-popover placement="top" width="200" trigger="click">
          <LayerManage :layers="cadLayers" @change="changeCadLayer" />
          <el-button type="success" slot="reference" size="mini">CAD图层</el-button>
        </el-popover>
        <el-dropdown @command="handleMeasureSelect">
          <el-button type="primary" size="mini">测量</el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="measureDist">测量距离</el-dropdown-item>
            <el-dropdown-item command="measureArea">测量面积</el-dropdown-item>
            <el-dropdown-item command="measureAngle">测量角度</el-dropdown-item>
            <el-dropdown-item command="measureCoordinate">测量坐标</el-dropdown-item>
            <el-dropdown-item command="measureCancel">取消测量</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-button-group>
      
      <el-tooltip effect="dark" content="显示或隐藏右侧工具栏" placement="top" style="margin-left: 8px">
        <el-button :icon="!previewHideControl ? 'el-icon-view' : 'el-icon-switch-button'" circle size="mini" type="success" @click="previewHideControl = !previewHideControl"/>
      </el-tooltip>
    </div>
  </div>
</template>

<script>
import { switchCadLayers, runMeasureCmd } from '@vjmap/common';
import vjmap from 'vjmap'
import LayerManage from "./LayerManage.vue";
export default {
  name: "ToolBar",
  components: {
    LayerManage
  },
  data() {
    return {
      dataLayers: [],
      cadLayers: [],
      previewHideControl: false
    }
  },
  inject: ["getMapApp"],
  created() {
    this.dataLayers = [];
    let mapApp = this.getMapApp();
    // 获取数据图层
    for (let i = 0; i < mapApp.layers.length; i++) {
      this.dataLayers.push({
        index: mapApp.layers[i].layerId,
        color: vjmap.randomColor(),
        name: `${mapApp.layers[i].memo ?? ''} ${mapApp.layers[i].layerId}`,
        isOff: mapApp.layers[i].visibleOff
      })
    }

    // 获取cad图层
    this.cadLayers = [];
    let map = mapApp.map;
    let svc = map.getService();
    if (!mapApp.isWebBaseMap() && mapApp.config.mapOpenOptions?.mapid) {
      this.cadLayers = svc.getMapLayers().map(m => {
        return {
          index: m.index,
          color: vjmap.randomColor(),
          name: m.name,
          isOff: m.isOff
        }
      })
    }
  },
  methods: {
    changeDataLayer(layers) {
      let mapApp = this.getMapApp();
      for (let i = 0; i < layers.length; i++) {
        let idx = mapApp.layers.findIndex(m => m.layerId == layers[i].index);
        if (idx == -1) continue;
        if (mapApp.layers[idx].visibleOff != layers[i].isOff) {
          mapApp.setLayerVisible(mapApp.layers[idx].layerId, layers[i].isOff);
        }
      }
    },
    async changeCadLayer(layers) {
      let mapApp = this.getMapApp();
      let map = mapApp.map;
      await switchCadLayers(map, layers);
    },
    handleMeasureSelect(key) {
      let mapApp = this.getMapApp();
      let map = mapApp.map;
      runMeasureCmd(map, key);
    }
  }
}
</script>

<style>
/* 把这里面的样式做为全局样式，以供例子中演示调用 */
.my-custom-popup .vjmapgis-popup-content {
  background-color: #57ffffbd;
}

.my-custom-popup .vjmapgis-popup-tip {
  border-top-color: #57ffffbd !important;
}

.rt-card {
  position: absolute;
  top: 5px;
  right: 70px;
}

.rt-card .toolbar {
  opacity: 0.7;
}
</style>