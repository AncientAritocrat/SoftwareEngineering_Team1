import router from "..";
/**
 * Vue-router Navigation Guard
 */
//External Route Guard Before Routing
router.beforeEach((to, from, next) => { })

//External Route Guard After Routing
router.afterEach((to, from) => { })