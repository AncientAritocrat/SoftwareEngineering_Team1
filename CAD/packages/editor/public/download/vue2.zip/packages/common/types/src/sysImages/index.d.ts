declare const _default: Record<string, any>;
export default _default;
