import { Map, Service } from "vjmap";
import type { CircleLayerStyleProp, FillExtrusionLayerStyleProp, FillLayerStyleProp, HeatmapLayerStyleProp, HillshadeLayerStyleProp, IOpenMapParam, LineLayerStyleProp, MapOptions, RasterLayerStyleProp, SourceSpecification, SymbolLayerStyleProp } from "vjmap";
export interface MapConfig extends MapOptions {
    isFitMapBounds?: boolean;
}
export interface MapOpenOptions extends IOpenMapParam {
    isKeepOldLayers?: boolean;
    isVectorStyle?: boolean;
    isSetCenter?: boolean;
    isFitBounds?: boolean;
}
export interface MapSource {
    id: string;
    props: SourceSpecification;
}
export type LayerSpecification = LineLayerStyleProp | FillLayerStyleProp | CircleLayerStyleProp | SymbolLayerStyleProp | RasterLayerStyleProp | FillExtrusionLayerStyleProp | HeatmapLayerStyleProp | HillshadeLayerStyleProp;
export interface MapLayer {
    id: string;
    source: string;
    type: "line" | "fill" | "circle" | "symbol" | "video" | "raster" | "fill-extrusion" | "heatmap" | "hillshade";
    props: LayerSpecification;
    before?: string;
}
export interface MapAppConfig {
    id?: string;
    title?: string;
    serviceUrl?: string;
    serviceToken?: string;
    accessKey?: string;
    workspace?: string;
    thumbnail?: string;
    backgroundColor?: string;
    mapOpenOptions?: MapOpenOptions;
    mapOptions?: MapConfig;
    mapSources?: MapSource[];
    mapLayers?: MapLayer[];
}
declare class MapApp {
    config: MapAppConfig;
    svc: Service;
    map: Map;
    sources: MapSource[];
    layers: MapLayer[];
    constructor(config?: MapAppConfig);
    mount(containerId: string, env?: {
        serviceUrl: string;
        serviceToken: string;
    }): void;
    setConfig(config?: MapAppConfig): Promise<{
        error: any;
    } | undefined>;
    setMapOpenOptions(option: Partial<MapOpenOptions>): void;
    setMapOptions(option: MapOptions): void;
    /**
     * 清空地图上的所有数据
     */
    clearData(): Promise<void>;
    /**
     * 切换地图
     * @param param 打开选项
     */
    switchMap(param: MapOpenOptions): Promise<any>;
    /**
     * 增加数据源
     */
    addSource(source: MapSource): void;
    /**
     * 生成一个随机geojson点数据源
     * @return {GeoPoint}
     * @param xRatio x轴范围比例 缺省 0.6
     * @param yRatio y轴范围比例 缺省 0.6
     * @param count 点的数目
     * @param propertiesCb 属性回调函数
     */
    addRandomGeoJsonPointSource(count: number, xRatio?: number, yRatio?: number, propertiesCb?: (index: number) => Object): void;
    /**
     * 生成一个随机geojson线数据源
     * @return {GeoPoint}
     * @param xRatio x轴范围比例 缺省 0.6
     * @param yRatio y轴范围比例 缺省 0.6
     * @param maxLineCount 最多线的数目
     * @param maxPointCount 每条线最多的点的数目
     * @param propertiesCb 属性回调函数
     */
    addRandomGeoJsonLineSource(maxLineCount: number, maxPointCount: number, xRatio?: number, yRatio?: number, propertiesCb?: (index: number) => Object): void;
    /**
     * 生成一个随机geojson多边形数据源
     * @return {GeoPoint}
     * @param xRatio x轴范围比例 缺省 0.6
     * @param yRatio y轴范围比例 缺省 0.6
     * @param maxPolygonCount 最多多边形的数目
     * @param maxPointCount 每条线最多的点的数目
     * @param propertiesCb 属性回调函数
     */
    addRandomGeoJsonPolygonSource(maxPolygonCount: number, maxPointCount: number, xRatio?: number, yRatio?: number, propertiesCb?: (index: number) => Object): void;
    /**
     * 设置数据源数据
     */
    setSourceData(sourceId: string, data?: any): void;
    /**
     * 删除数据源
     */
    removeSource(sourceId: string): void;
    /**
     * 增加图层
     */
    addLayer(layer: MapLayer): void;
    /**
     * 设置图层属性
     */
    setLayerStyle(layerId: string, layerProps: LayerSpecification): void;
    /**
     * 删除图层
     */
    removeLayer(layerId: string): void;
    /**
     * 获取配置
     */
    getConfig(): MapAppConfig;
    static guid(digit?: number): string;
}
export default MapApp;
