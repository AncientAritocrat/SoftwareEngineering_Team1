import type { Map } from "vjmap";
export declare const selectFeatures: (map: Map, useGeomCoord?: boolean, includeWholeEntity?: boolean, isPointSel?: boolean, disableSnap?: boolean, disableSelectEntities?: Set<String>) => Promise<any>;
