<template>
  <div>
    <div class="rt-card">
      <el-space>
        <el-button-group size="small" v-if="!app.previewHideControl" class="toolbar">
          <el-popover placement="bottom" width="200" trigger="click">
            <template #reference>
              <el-button type="primary" round>数据图层</el-button>
            </template>
            <LayerManage :layers="dataLayers" @change="changeDataLayer" />
          </el-popover>
          <el-popover placement="top" width="200" trigger="click">
            <template #reference>
              <el-button type="success">CAD图层</el-button>
            </template>
            <LayerManage :layers="cadLayers" @change="changeCadLayer" />
          </el-popover>
          <el-dropdown @command="(cmd: string)=>handleMeasureSelect(cmd)">
                <el-button>测量</el-button>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item command="measureDist">测量距离</el-dropdown-item>
                        <el-dropdown-item command="measureArea">测量面积</el-dropdown-item>
                        <el-dropdown-item command="measureAngle">测量角度</el-dropdown-item>
                        <el-dropdown-item command="measureCoordinate">测量坐标</el-dropdown-item>
                        <el-dropdown-item command="measureCancel">取消测量</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </el-button-group>
        <el-tooltip effect="dark" content="显示或隐藏右侧工具栏" placement="top">
          <el-button color="#54B365" size="small" circle @click="app.previewHideControl = !app.previewHideControl">
            <template #icon>
              <el-icon v-if="!app.previewHideControl">
                <View/>
              </el-icon>
              <el-icon v-else>
                <Hide />
              </el-icon>
            </template>
          </el-button>
        </el-tooltip>
      </el-space>
    </div>
  </div>
</template>

<script lang="ts" setup>
import type { MapApp } from '@vjmap/common';
import vjmap from 'vjmap'
import type { Map } from 'vjmap'
import { inject, ref } from 'vue';
import LayerManage from "./LayerManage.vue";
import { runMeasureCmd, switchCadLayers } from '@vjmap/common';
import { useAppStore } from '../stores/app';
const app = useAppStore();
const dataLayers = ref<{ index: string; color: string; name: string; isOff?: boolean }[]>([]);
const cadLayers = ref<{ index: string; color: string; name: string; isOff?: boolean }[]>([]);
const mapApp = inject<MapApp>('mapApp') as MapApp;
const map = mapApp?.map as Map;
let svc = map.getService();
// 获取数据图层
for (let i = 0; i < mapApp.layers.length; i++) {
  dataLayers.value.push({
    index: mapApp.layers[i].layerId,
    color: vjmap.randomColor(),
    name: `${mapApp.layers[i].memo ?? ''} ${mapApp.layers[i].layerId}`,
    isOff: mapApp.layers[i].visibleOff
  })
}

// 获取cad图层
cadLayers.value = [];
if (!mapApp.isWebBaseMap() && mapApp.config.mapOpenOptions?.mapid) {
  cadLayers.value = svc.getMapLayers().map(m => {
    return {
      index: m.index + '',
      color: vjmap.randomColor(),
      name: m.name,
      isOff: m.isOff
    }
  })
}


const changeDataLayer = (layers: any) => {
  for (let i = 0; i < layers.length; i++) {
    let idx = mapApp.layers.findIndex(m => m.layerId == layers[i].index);
    if (idx == -1) continue;
    if (mapApp.layers[idx].visibleOff != layers[i].isOff) {
      mapApp.setLayerVisible(mapApp.layers[idx].layerId, layers[i].isOff);
    }
  }
}

const changeCadLayer = async (layers: any) => {
  await switchCadLayers(map, layers, mapApp.config.mapOpenOptions?.isVectorStyle ?? false);
}

const handleMeasureSelect = (key: string) => {
  const map = mapApp?.map as Map;
  runMeasureCmd(map, key);
}
</script>

<style>
/* 把这里面的样式做为全局样式，以供例子中演示调用 */
.my-custom-popup .vjmapgis-popup-content {
  background-color: #57ffffbd;
}

.my-custom-popup .vjmapgis-popup-tip {
  border-top-color: #57ffffbd !important;
}

.rt-card {
  position: absolute;
  top: 5px;
  right: 70px;
}

.rt-card .toolbar {
  opacity: 0.7;
}
</style>