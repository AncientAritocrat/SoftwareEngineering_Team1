<template>
  <div>
    <div id="mapContainer"></div>
    <UILayer v-if="isLoaded"></UILayer>
  </div>
</template>

<script setup lang="ts">
import 'vjmap/dist/vjmap.min.css'
import { MapApp } from '@vjmap/common'
import { onMounted, onUnmounted, provide, ref } from 'vue'
import config from '../data/config'
import UILayer from '../components/UILayer.vue';
import { useAppStore } from '../stores/app';
import { onMapLoaded } from '../lib/program'
const app = useAppStore();
const isLoaded = ref(false);
const mapApp = new MapApp();
provide("mapApp", mapApp); // 地图对象
onMounted(async () => {
  mapApp.mount("mapContainer");
  let cfg = config as any;
  cfg.serviceUrl = cfg.serviceUrl ?? app.serviceUrl;
  cfg.serviceToken = cfg.serviceToken ?? app.accessToken;
  // isDisableRunProgram设置为true，表示不执行配置中的逻辑代码，执行下面onMapLoaded函数中的代码，这样方便书写和调试
  mapApp.isDisableRunProgram = true;
  await mapApp.setConfig(cfg);
  if (mapApp.isDisableRunProgram) {
    // 方便在这里写逻辑代码调试，然后复制到配置中的逻辑代码中去
    await onMapLoaded(mapApp.map, mapApp);
  }
  isLoaded.value = true;
})
onUnmounted(() => {
  mapApp.destory();
});
</script>

<style lang="scss" scoped>
#mapContainer {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: #022b4f;
}
</style>