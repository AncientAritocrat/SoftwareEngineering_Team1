<template>
  <div class="div-container">
    <ToolBar/>
  </div>
</template>

<script lang="ts" setup>
import ToolBar from "./ToolBar.vue";
</script>

<style scoped>
.div-container {
  z-index: 2
}
</style>