<template>
  <div class="app">
     <router-view></router-view>
   </div>
 </template>
 
 <style >
 * {
   margin: 0;
   padding: 0;
 }
 </style>
 