import * as vjcommon from './export'
export * from './export'
export default vjcommon;