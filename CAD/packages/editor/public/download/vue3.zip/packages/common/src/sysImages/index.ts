import scatterDot from "./scatterDot";
import pulsingDot from "./pulsingDot"
export default {
    "scatterDot": scatterDot, // 扩散的点
    "pulsingDot": pulsingDot 
} as Record<string, any>