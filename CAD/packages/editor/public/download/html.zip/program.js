async function onMapLoaded(map, mapApp, context) {
  // onMapLoadedCode
  
}
