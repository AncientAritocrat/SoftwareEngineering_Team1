import type { Map } from 'vjmap';
export declare const getMapSnapPoints: (map: Map, snapObj: any, snapQueryLimit?: number) => Promise<void>;
