export declare const locale: {
    'FullscreenControl.Enter': string;
    'FullscreenControl.Exit': string;
    'NavigationControl.ZoomIn': string;
    'NavigationControl.ZoomOut': string;
    'NavigationControl.ResetBearing': string;
    'ScaleControl.Meters': string;
    'ScaleControl.Kilometers': string;
};
