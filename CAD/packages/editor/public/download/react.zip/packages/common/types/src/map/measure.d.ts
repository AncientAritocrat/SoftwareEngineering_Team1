import { Map } from 'vjmap';
export declare function runMeasureCmd(map: Map, cmd: string): Promise<void>;
