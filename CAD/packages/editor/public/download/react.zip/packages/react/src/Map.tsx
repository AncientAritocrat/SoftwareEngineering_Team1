import { useEffect } from 'react';
import { MapApp } from '@vjmap/common'
import 'vjmap/dist/vjmap.min.css'
import "./Map.css"
import config from './data/config';
import { onMapLoaded } from './lib/program'
const Map = () => {
    const mapApp = new MapApp();
    const loadMap = async () => {
        const env = {
            serviceUrl: "https://vjmap.com/server/api/v1",
            accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6MSwiVXNlcm5hbWUiOiJyb290MSIsIk5pY2tOYW1lIjoicm9vdDEiLCJBdXRob3JpdHlJZCI6InJvb3QiLCJCdWZmZXJUaW1lIjo4NjQwMCwiZXhwIjoxOTQyMzA1MjQxLCJpc3MiOiJ2am1hcCIsIm5iZiI6MTYyNjk0NDI0MX0.29OAA4Cnjtw780VxIxWqduLtszp1EtpSNHAmWjiL_OM",
        };
        mapApp.mount("map-container");
        let cfg = config as any;
        cfg.serviceUrl = cfg.serviceUrl ?? env.serviceUrl;
        cfg.serviceToken = cfg.serviceToken ?? env.accessToken;
        // isDisableRunProgram设置为true，表示不执行配置中的逻辑代码，执行下面onMapLoaded函数中的代码，这样方便书写和调试
        mapApp.isDisableRunProgram = true;
        await mapApp.setConfig(cfg);
        if (mapApp.isDisableRunProgram) {
            // 方便在这里写逻辑代码调试，然后复制到配置中的逻辑代码中去
            await onMapLoaded(mapApp.map, mapApp);
        }

        // 退出移除
        return () => mapApp.destory();
    }
    // 初始化
    useEffect(() => {
        loadMap();
    }, []);


    return (
        <div>
            <div id='map-container'/>
        </div>
    );
};

export default Map;